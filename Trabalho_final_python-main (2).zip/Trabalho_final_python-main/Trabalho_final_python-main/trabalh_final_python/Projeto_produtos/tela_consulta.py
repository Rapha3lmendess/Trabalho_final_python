import tkinter as tk
from tkinter import ttk
from conexao import conectar

def abrir_consulta():

    janela = tk.Toplevel()
    janela.title("Consulta")

    tabela = ttk.Treeview(
        janela,
        columns=("Nome", "Preco", "Quantidade"),
        show="headings"
    )

    tabela.heading("Nome", text="Nome")
    tabela.heading("Preco", text="Preço")
    tabela.heading("Quantidade", text="Quantidade")

    tabela.pack(fill="both", expand=True)

    conexao = conectar()
    cursor = conexao.cursor()

    cursor.execute("SELECT nome, preco, quantidade FROM produtos")

    produtos = cursor.fetchall()

    for produto in produtos:
        tabela.insert("", "end", values=produto)

    cursor.close()
    conexao.close()