from conexao import conectar

def listar_produtos():
    conexao = conectar()
    cursor = conexao.cursor()

    cursor.execute("SELECT nome, preco, quantidade FROM produtos")
    produtos = cursor.fetchall()

    cursor.close()
    conexao.close()

    return produtos