# Trabalho_final_python

Feito por Raphael alves Mendes projeto feito em sala com dicas do professor, mysql possivelmente funcionando, tive bastante dificuldade


codigo para dentro do mysql workbench

CREATE DATABASE IF NOT EXISTS controle_estoque;

USE controle_estoque;

CREATE TABLE IF NOT EXISTS produtos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    preco DECIMAL(10,2) NOT NULL,
    quantidade INT NOT NULL
);

SELECT * FROM produtos;    33333333333333